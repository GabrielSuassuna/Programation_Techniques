class Operator extends Expression{
	char op;
	Expression right, left;

	Operator(Expression left, char op, Expression right){
		this.op = op;
		this.right = right;
		this.left = left;
	}

	double operation(){
		if(this.op == '*'){
			double result;
			result = left.operation() * right.operation();
			this.getState(result);
			return result;
		}
		else{
			double result;
			result = left.operation() / right.operation();
			this.getState(result);
			return result;
		}
	}

	void getState(double result){
		if (result > 0){
			updatePositive();
		} else {
			updateNegative();
		}
	}

	void updatePositive(){
		System.out.println("Valor positivo");
	}

	void updateNegative(){
		System.out.println("Valor menor ou igual a zero");
	}

	Expression[] getChild(int i){return null;}
	void add(Expression e){}
	void remove(Expression e){}
}