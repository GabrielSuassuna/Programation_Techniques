interface Colorido{
    void colorir(String cor);
}